
import json
import gradio as gr
import spaces
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image


# ---------------- LOAD PROJECT FILES ----------------

def load_project():

    with open("food_classes.json", "r", encoding="utf-8") as f:
        food_classes = json.load(f)

    with open("food_calories.json", "r", encoding="utf-8") as f:
        food_calories = json.load(f)

    if isinstance(food_classes, dict):
        food_classes = [
            food_classes[str(i)] if str(i) in food_classes else food_classes[i]
            for i in range(len(food_classes))
        ]

    # Load model on CPU first
    model = models.resnet18(weights=None)
    model.fc = nn.Linear(model.fc.in_features, len(food_classes))

    state_dict = torch.load(
        "food_classification_model.pth",
        map_location="cpu",
        weights_only=True
    )

    model.load_state_dict(state_dict)
    model.eval()

    image_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])

    return model, food_classes, food_calories, image_transform


# ---------------- INITIALIZE MODEL ----------------

model, food_classes, food_calories, image_transform = load_project()


# ---------------- FOOD PREDICTION ----------------

@spaces.GPU
def predict_food(image, weight):

    if image is None:
        return "Please upload or capture a food image.", "", ""

    if weight is None or weight <= 0:
        return "Please enter a valid food weight.", "", ""

    image = image.convert("RGB")

    device = torch.device("cuda")

    try:
        model.to(device)
        input_tensor = image_transform(image).unsqueeze(0).to(device)

        with torch.no_grad():
            output = model(input_tensor)
            probabilities = torch.softmax(output, dim=1)
            confidence, predicted_index = probabilities.max(dim=1)

        food_name = food_classes[predicted_index.item()]
        confidence_score = confidence.item() * 100

        display_name = food_name.replace("_", " ").title()

        if food_name not in food_calories:
            return display_name, f"{confidence_score:.2f}%", "Calorie information unavailable."

        calories_per_100g = float(food_calories[food_name])
        estimated_calories = calories_per_100g * weight / 100

        calorie_result = (
            f"{estimated_calories:.2f} kcal "
            f"for {weight:.0f} grams"
        )

        return (
            display_name,
            f"{confidence_score:.2f}%",
            calorie_result
        )

    finally:
        model.to("cpu")
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


# ---------------- GRADIO WEBSITE ----------------

with gr.Blocks(title="AI Food Calorie Estimator") as demo:

    gr.Markdown(
        """
        # AI-Based Food Calorie Estimation

        Upload a food image or use your camera to identify food
        and estimate its calories.
        """
    )

    with gr.Row():

        image_input = gr.Image(
            label="Upload Food Image or Use Camera",
            type="pil",
            sources=["upload", "webcam"]
        )

        with gr.Column():

            weight_input = gr.Number(
                label="Food Weight (grams)",
                value=100,
                minimum=1
            )

            predict_button = gr.Button(
                "Predict Food and Estimate Calories",
                variant="primary"
            )

    gr.Markdown("## Prediction Results")

    food_output = gr.Textbox(label="Predicted Food")
    confidence_output = gr.Textbox(label="Model Confidence")
    calories_output = gr.Textbox(label="Estimated Calories")

    predict_button.click(
        fn=predict_food,
        inputs=[image_input, weight_input],
        outputs=[
            food_output,
            confidence_output,
            calories_output
        ]
    )

    gr.Markdown(
        """
        **Note:** Food weight is entered manually.
        Calorie values are approximate reference values per 100 grams.
        """
    )


# ---------------- LAUNCH APPLICATION ----------------

demo.launch()
